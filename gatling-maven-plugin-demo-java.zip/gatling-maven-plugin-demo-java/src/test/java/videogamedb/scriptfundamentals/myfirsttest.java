package videogamedb.scriptfundamentals;

import edu.umd.cs.findbugs.annotations.NonNull;
import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

public class myfirsttest extends Simulation {
    //1 HTTP Configuration (set basEURL, Headers)
    private HttpProtocolBuilder httpprotocol = http
            .baseUrl("https://videogamedb.uk:443/api/")
            .acceptHeader("application/json");

    // 2 Scenario Definition
    private ScenarioBuilder scn = scenario("My First Scenario")
            .exec((http("Get all the games for sakshi")
                    .get("/videogame")));

    //3 Load Scenario

    {
        setUp(
                scn.injectOpen(atOnceUsers(1))
        ).protocols(httpprotocol);

    }
}
