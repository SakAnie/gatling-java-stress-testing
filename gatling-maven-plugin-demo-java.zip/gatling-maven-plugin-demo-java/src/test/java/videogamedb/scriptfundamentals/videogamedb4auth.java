package videogamedb.scriptfundamentals;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;

public class videogamedb4auth extends Simulation {
    //1 HTTP Configuration (set basEURL, Headers)
    private HttpProtocolBuilder httpprotocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json")
            //add below header to be able to post json object
            .contentTypeHeader("application/json");

    //Writing methods for each scenario - modularising- To Build a chain of REST calls in order to Feed it to the Scenario
    //ChainBuilder -Used to execute a specific chain of actions only when some condition is satisfied.


    //Step1:Define Authenticate post method and extract the access token from its response
    private static ChainBuilder authenticatemethod =
            exec(http("Auhenticate for post api call")
                    .post("/authenticate")
                    .body(StringBody("{\n" +
                            "  \"password\": \"admin\",\n" +
                            "  \"username\": \"admin\"\n" +
                            "}"))
                    .check(jmesPath("token").saveAs("mytoken")));

    //step2: define createNewresource method by passing header as the accessotoken
    private static ChainBuilder createNewgame =

            exec(http("Create new game")
                    .post("/videogame")
                    .header("Authorization", "#{mytoken}")
                    .body(StringBody("{\n" +
                            "  \"category\": \"Platform\",\n" +
                            "  \"name\": \"Mario\",\n" +
                            "  \"rating\": \"Mature\",\n" +
                            "  \"releaseDate\": \"2012-05-04\",\n" +
                            "  \"reviewScore\": 85\n" +
                            "}")));


    //Use the methods in creating scenario using ScenarioBuilder
    private ScenarioBuilder scn = scenario("---Create a New video game---")
            //First to call authenticate method in scenariobuilder before calling post
            .exec(authenticatemethod)
            .exec(createNewgame);


    //3 Load Scenario

    {
        setUp(
                scn.injectOpen(atOnceUsers(1))
        ).protocols(httpprotocol);

    }

}
