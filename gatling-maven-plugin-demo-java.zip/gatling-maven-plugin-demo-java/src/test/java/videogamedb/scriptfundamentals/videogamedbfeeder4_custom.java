package videogamedb.scriptfundamentals;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;
import org.apache.commons.lang3.RandomStringUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import java.util.stream.Stream;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;


public class videogamedbfeeder4_custom extends Simulation {
    //1 HTTP Configuration (set basEURL, Headers)
    private HttpProtocolBuilder httpprotocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json")
            //add below header to be able to post json object
            .contentTypeHeader("application/json");

    public static LocalDate randomData() {
        int hundredYears = 100 * 365;
        return LocalDate.ofEpochDay(ThreadLocalRandom.current().nextInt(-hundredYears, hundredYears));
    }

    // Purpose fo complex feeder-To create a new game with new ID,Name and all meta data.
    //used when we do not have static input data files (csv,json etc)
    // The random hmap data generated here will be fed to newGameTemplate.json
    // Complex custom feeder- feeding a randomly created COMPLEX "json " as an input to CREATE A BRAND NEW GAME!!
    private static Iterator<Map<String, Object>> customFeeder =
            Stream.generate((Supplier<Map<String, Object>>) () -> {
                Random rand = new Random();
                int gameID = rand.nextInt(10 - 1 + 1) + 1;
                String gameName = RandomStringUtils.randomAlphanumeric(5) + "-gameName";
                String releaseDate = randomData().toString();
                int reviewScore = rand.nextInt(100);
                String category = RandomStringUtils.randomAlphanumeric(5) + "-category";
                String rating = RandomStringUtils.randomAlphanumeric(4) + "-rating";
                HashMap<String, Object> hmap = new HashMap<String, Object>();
                hmap.put("gameID", gameID);
                hmap.put("gameName", gameName);
                hmap.put("releaseDate", releaseDate);
                hmap.put("reviewScore", reviewScore);
                hmap.put("category", category);
                hmap.put("rating", rating);
                return hmap;

            }).iterator();

    //Step2 : Scenario Definition
    private static ChainBuilder authenticate =
            exec(http("Authenticate")
                    .post("/authenticate")
                    .body(StringBody("{\n" +
                            "  \"password\": \"admin\",\n" +
                            "  \"username\": \"admin\"\n" +
                            "}"))

                    //extract the token to fed into header while calling the post api
                    .check(jmesPath("token").saveAs("jwtToken")));

    private static ChainBuilder createNewGame =
            feed(customFeeder)
                    .exec(http("Create New Game with name #{gameName}")
                            .post("/videogame")
                            .header("authorization", "Bearer #{jwtToken}")
                            //customerfeeder generated random values will be fed to newGameTemplate.json attributes on the fly
                            .body(ElFileBody("data/newGameTemplate.json")).asJson()
                            .check(bodyString().saveAs("responseBody")))
                    .exec(session -> {
                        System.out.println(session.getString("responseBody"));
                        return session;
                    });


    //Use the methods in creating scenario using ScenarioBuilder
    private ScenarioBuilder scn = scenario("---Create a New video game---")
            //First to call authenticate method in scenariobuilder before calling post
            .exec(authenticate)
            .exec(createNewGame);


    //3 Load Scenario

    {
        setUp(
                scn.injectOpen(atOnceUsers(1))
        ).protocols(httpprotocol);

    }

}
