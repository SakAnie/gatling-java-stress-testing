package videogamedb.scriptfundamentals;

import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;
import io.gatling.recorder.internal.bouncycastle.oer.its.ieee1609dot2.basetypes.UINT16;

import java.time.Duration;
import java.util.List;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

public class videogamedb extends Simulation {
    //1 HTTP Configuration (set basEURL, Headers)
    private HttpProtocolBuilder httpprotocol = http
            .baseUrl("https://videogamedb.uk:443/api/")
            .acceptHeader("application/json");

    // 2 Scenario Definition
    private ScenarioBuilder scn = scenario("Video Game db ***new**")


            .exec(http("Get specific game by name")
                    .get("/videogame/1")
                    .check(status().in(200, 201, 202))
                    .check(jmesPath("name").is("Resident Evil 4")))
            .pause(1, 10)
            .exec(http("Get all video games ")
                    .get("/videogame")
                    .check(status().not(404), status().not(500))
                    .check(jmesPath("[1].id").saveAs("var")))
            .pause(5)

            //To capture session details for DEBUGGING
            .exec(
                    session -> {
                        System.out.println(session);
                        System.out.println("gameId set to: " + session.getString("var"));
                        return session;
                    }
            )
            .exec(http("getting sp game with id  #{var}")
                    .get("/videogame/#{var}")
                    .check(jmesPath("name").is("Gran Turismo 3"))

                    //Capture the Response Body using BodyString().saveAs()
                    .check(bodyString().saveAs("responseBody")))

            //To print the response body in the console
            .exec(
                    session -> {
                        System.out.println("Response Body" + session.getString("responseBody"));
                        return session;
                    }
            );

    //3 Load Scenario

    {
        setUp(
                scn.injectOpen(atOnceUsers(1))
        ).protocols(httpprotocol);

    }

}
