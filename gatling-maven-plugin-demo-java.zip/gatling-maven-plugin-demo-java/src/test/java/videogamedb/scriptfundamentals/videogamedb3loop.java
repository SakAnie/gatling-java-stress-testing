package videogamedb.scriptfundamentals;

import io.gatling.javaapi.core.*;
import io.gatling.javaapi.http.*;
import io.gatling.recorder.internal.bouncycastle.oer.its.ieee1609dot2.basetypes.UINT16;

import java.time.Duration;
import java.util.List;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.*;

public class videogamedb3loop extends Simulation {
    //1 HTTP Configuration (set basEURL, Headers)
    private HttpProtocolBuilder httpprotocol = http
            .baseUrl("https://videogamedb.uk:443/api/")
            .acceptHeader("application/json");

    //Writing methods for each scenario - modularising- To Build a chain of REST calls in order to Feed it to the Scenario
    //ChainBuilder -Used to execute a specific chain of actions only when some condition is satisfied.
    private static ChainBuilder getAllVideGames =
            repeat(3).on(
                    exec(http("Get all video games under method")
                            .get("/videogame")
                            .check(status().not(404), status().not(500))));

    private static ChainBuilder getSpecificVideoGame =
            repeat(5, "myCounter").on(
                    exec(http("Get specific video game with id  ** #{myCounter}*** under method")
                            .get("/videogame/#{myCounter}")
                            .check(status().is(200))));
    //Use the methods in creating scenario using ScenarioBuilder
    private ScenarioBuilder scn = scenario("---Video Game db fetch from chainBuilder methods---")
            .exec(getAllVideGames)
            .pause(5)
            .exec(getSpecificVideoGame)
            .pause(5)
            .repeat(2).on(
                    //we can also add  loops in inside  the scenariobuilder
                    exec(getSpecificVideoGame)
            );


    //3 Load Scenario

    {
        setUp(
                scn.injectOpen(atOnceUsers(1))
        ).protocols(httpprotocol);

    }

}
