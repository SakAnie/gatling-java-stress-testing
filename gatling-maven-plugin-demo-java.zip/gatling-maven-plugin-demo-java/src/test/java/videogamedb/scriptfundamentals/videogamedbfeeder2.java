package videogamedb.scriptfundamentals;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.FeederBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;

public class videogamedbfeeder2 extends Simulation {
    //1 HTTP Configuration (set basEURL, Headers)
    private HttpProtocolBuilder httpprotocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json")
            //add below header to be able to post json object
            .contentTypeHeader("application/json");

    //Feeder Builder
    private static FeederBuilder.FileBased<Object> jsonFeeder = jsonFile("data/myjson.json").random();

    //Step2 : Scenario Definition
    private static ChainBuilder getSpecificVideoGame =
            feed(jsonFeeder)
                    .exec(http("Get specific video game with name - #{name}")
                            .get("/videogame/#{id}")
                            .check(jmesPath("name").isEL("#{name}")));
    //isEL --> is expression language, gatlingcan read from variables to assert!!!

    //Use the methods in creating scenario using ScenarioBuilder
    private ScenarioBuilder scn = scenario("---Create a New video game---")
            //First to call authenticate method in scenariobuilder before calling post
            .repeat(10).on(
                    exec(getSpecificVideoGame)
                            .pause(1)
            );


    //3 Load Scenario

    {
        setUp(
                scn.injectOpen(atOnceUsers(1))
        ).protocols(httpprotocol);

    }

}
