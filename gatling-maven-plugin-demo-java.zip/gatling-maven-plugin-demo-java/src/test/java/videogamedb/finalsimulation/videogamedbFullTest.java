package videogamedb.finalsimulation;


import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.FeederBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.core.CoreDsl.jmesPath;
import static io.gatling.javaapi.http.HttpDsl.http;

public class videogamedbFullTest extends Simulation {
    //STEP1:HTTP PROTOCOL
    private HttpProtocolBuilder httpProtocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json")
            .contentTypeHeader(("application/json"));


    //STEP1.2: RUNTIME PARAMETERS
    private static final int USER_COUNT = Integer.parseInt(System.getProperty("USERS", "5"));
    private static final int RAMP_DURATION = Integer.parseInt(System.getProperty("RAMP_DURATION", "10"));
    private static final int TEST_DURATION = Integer.parseInt(System.getProperty("TEST_DURATION", "20"));


    //STEP1.3: FEEDER FOR TEST - JSON
    private static FeederBuilder.FileBased<Object> jsonFeeder = jsonFile("data/myjson.json").random();

    //STEP1.4: BEFORE BLOCK
    public void before() {
        System.out.printf("Running test with %d user%n", USER_COUNT);
        System.out.printf("Ramping users over %d seconds%n", RAMP_DURATION);
        System.out.printf("Total test duration: %d seconds%n", TEST_DURATION);
    }

    //STEP2: DEFINE CHAINBUILDERS FOR SCENARIOBUILDER  -  HTTP CALLS

    //SCENARIO OR USER JOURNEY
    //1. GET ALL VIDEOGAMES
    //2. CREATE A NEW GAME
    //3. GET DETAILS OF NEWLY CREATED GAME
    //4.DELETE NEWLY CREATED GAME
    private static ChainBuilder authenticatemethod =
            exec(http("Auhenticate for post api call")
                    .post("/authenticate")
                    .body(StringBody("{\n" +
                            "  \"password\": \"admin\",\n" +
                            "  \"username\": \"admin\"\n" +
                            "}"))
                    .check(jmesPath("token").saveAs("mytoken")));

    private static ChainBuilder getAllVideoGames =
            exec(http("Get all video games/transactions")
                    .get("/videogame"));

    private static ChainBuilder createNewGame =
            feed(jsonFeeder)
                    .exec(http("Create New Game with name #{name}")
                            .post("/videogame")
                            .header("authorization", "Bearer  #{mytoken}")
                            //customerfeeder generated random values will be fed to newGameTemplate.json attributes on the fly
                            .body(ElFileBody("data/newGameTemplate.json")).asJson()
                    );

    private static ChainBuilder getLastPostedGame =
            exec((http("Get last posted game - #{name}")
                    .get("/videgame/#{id}")
                    .check(jmesPath("name").isEL("#{name}")))
            );

    private static ChainBuilder deleteLastGame =
            exec(http("Get delected name- #{name}")
                    .delete("/videogame/#{id}")
                    .header("Authorization", "Bearer #{mytoken}")
                    .check(bodyString().is("Video game deleted")));

    //STEP2.1 SCENARIOBUILDER

    //SCENARIO OR USER JOURNEY
    //1. GET ALL VIDEOGAMES
    //2. CREATE A NEW GAME
    //3. GET DETAILS OF NEWLY CREATED GAME
    //4.DELETE NEWLY CREATED GAME
    private ScenarioBuilder scn = scenario("---****FINAL SIMULATION VIDEO GAME***---")
            //First to call authenticate method in scenariobuilder before calling post
            .forever().on(
                    exec(getAllVideoGames)
                            .pace(2)
                            .exec(authenticatemethod)
                            .pace(2)
                            .exec(createNewGame)
                            .pause(2)
                            .exec(getLastPostedGame)
                            .pace(2)
                            .exec(deleteLastGame)

            );




    //STEP3:LOAD SIMULATION
    {
        setUp(
                scn.injectOpen(
                        nothingFor(5),
                        rampUsers(USER_COUNT).during(RAMP_DURATION)

                ).protocols(httpProtocol)
        ).maxDuration(TEST_DURATION);

    }

    //STEP3.1 AFTER BLOCK
    @Override
    public void after(){
        System.out.println("stress testing completed using gatling");
    }
}
