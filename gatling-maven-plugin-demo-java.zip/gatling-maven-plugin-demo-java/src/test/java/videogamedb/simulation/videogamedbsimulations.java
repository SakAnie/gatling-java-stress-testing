package videogamedb.simulation;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.FeederBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;

public class videogamedbsimulations extends Simulation {
    private HttpProtocolBuilder httpProtocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json");

    private static ChainBuilder getAllVideoGames =
            exec(http("Get all video games/transactions")
                    .get("/videogame"));
    private static ChainBuilder getSpecificGame =
            exec(http("Get specific game")
                    .get("/videogame/2"));
    private ScenarioBuilder scn = scenario("Video game db -example for Simulations")
            .exec(getAllVideoGames)
            .pause(2)
            .exec(getSpecificGame)
            .pause(2)
            .exec(getAllVideoGames);

    //Open model Local simulation setup10
    {
        setUp(
                scn.injectOpen(
                        nothingFor(5),
                        //atOnceUsers(nbUsers) : Injects a given number of users at once.
                        atOnceUsers(5),
                       // rampUsers(nbUsers). during(duration) : Injects a given number of users distributed evenly on a time window of a given duration. constantUsersPerSec(rate). during(duration) : Injects users at a constant rate, defined in users per second, during a given duration.3
                        rampUsers(10).during(20),
                        //constantUsersPerSec(rate). during(duration) : Injects users at a constant rate, defined in users per second, during a given duration. Users will be injected at regular intervals.
                        constantUsersPerSec(5).during(10),
                        //to generate report a bit uneven more practical- not steep line
                        constantUsersPerSec(5).during(10).randomized(),
                        //injects users from starting rate to target rate, defined in users per second, during a given duration. Users will be injected at regular intervals.
                        rampUsersPerSec(1).to(5).during(20),
                        rampUsersPerSec(1).to(5).during(20).randomized()


                ).protocols(httpProtocol)
        );

    }

}
