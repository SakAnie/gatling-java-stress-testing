package videogamedb.simulation;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;

public class videogamedbsimulationsruntimeparam extends Simulation {
    private HttpProtocolBuilder httpProtocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json");

    //Run time parameters- if not set by user during run time,then defaults to value "def"
    private static final int USER_COUNT = Integer.parseInt(System.getProperty("USERS", "5"));
    private static final int RAMP_DURATION = Integer.parseInt(System.getProperty("RAMP_DURATION", "10"));
    private static final int TEST_DURATION = Integer.parseInt(System.getProperty("TEST_DURATION", "20"));

    //Before method will run at the start of our load Test- it will ask user for inputs
    public void before() {
        System.out.printf("Running test with %d user%n", USER_COUNT);
        System.out.printf("Ramping users over %d seconds%n", RAMP_DURATION);
        System.out.printf("Total test duration: %d seconds%n", TEST_DURATION);
    }

    private static ChainBuilder getAllVideoGames =
            exec(http("Get all video games/transactions")
                    .get("/videogame"));
    private static ChainBuilder getSpecificGame =
            exec(http("Get specific game")
                    .get("/videogame/2"));
    private ScenarioBuilder scn = scenario("Video game db -example for Simulations")
            .exec(getAllVideoGames)
            .pause(2)
            .exec(getSpecificGame)
            .pause(2)
            .exec(getAllVideoGames);

    //Open model Local simulation setup10
    {
        setUp(
                scn.injectOpen(
                        nothingFor(5),
                        rampUsers(USER_COUNT).during(RAMP_DURATION)

                ).protocols(httpProtocol)
        ).maxDuration(TEST_DURATION);

    }

}
