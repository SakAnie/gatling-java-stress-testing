package videogamedb.simulation;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;

public class videogamefixeddurationloadsimulation extends Simulation {
    private HttpProtocolBuilder httpProtocol = http
            .baseUrl("https://videogamedb.uk:443/api")
            .acceptHeader("application/json");

    private static ChainBuilder getAllVideoGames =
            exec(http("Get all video games/transactions")
                    .get("/videogame"));
    private static ChainBuilder getSpecificGame =
            exec(http("Get specific game")
                    .get("/videogame/2"));
    private ScenarioBuilder scn = scenario("Video game db -example for Simulations")
            .forever().on(
                    exec(getAllVideoGames)
                            .pause(2)
                            .exec(getSpecificGame)
                            .pause(2)
                            .exec(getAllVideoGames)
            );

    //Open model Local simulation setup10
    {
        setUp(
                scn.injectOpen(
                        nothingFor(5),
                        //atOnceUsers(nbUsers) : Injects a given number of users at once.
                        atOnceUsers(10),
                        // rampUsers(nbUsers). during(duration) : Injects a given number of users distributed evenly on a time window of a given duration. constantUsersPerSec(rate). during(duration) : Injects users at a constant rate, defined in users per second, during a given duration.3
                        rampUsers(20).during(30)
                ).protocols(httpProtocol)
        ).maxDuration(60);

    }

}
