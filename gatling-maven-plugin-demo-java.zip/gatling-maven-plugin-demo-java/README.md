POC for Gatling Java API Project for Load Testing
=================================================

A standard Gatling java implementation for personal POC of Load Testing 